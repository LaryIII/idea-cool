define(function(require, exports, mod) {
  exports.uri = mod.uri
});
