
seajs.config({
  map: [
    ['main.js', 'main.js?t=20130203'],
    ['a.js', 'a-debug.js']
  ]
});

