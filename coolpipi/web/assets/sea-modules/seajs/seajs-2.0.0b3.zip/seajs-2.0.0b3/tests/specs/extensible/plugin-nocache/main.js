
seajs.config({
  debug: true,
  plugins: ["nocache"]
})

seajs.use("./plugin-nocache/init")

