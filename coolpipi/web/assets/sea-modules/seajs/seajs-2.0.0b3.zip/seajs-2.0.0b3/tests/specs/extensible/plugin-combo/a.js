define({ name: 'wrong' })
