define('define-e', [], { name: 'e' });
