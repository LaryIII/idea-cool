define('a', [], { name: 'a' })
