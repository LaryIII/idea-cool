define({ name: 'f' })
