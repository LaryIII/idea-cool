define(
    {
      "name": "Frank Wang",
      "love": "JavaScript"
    }
);
