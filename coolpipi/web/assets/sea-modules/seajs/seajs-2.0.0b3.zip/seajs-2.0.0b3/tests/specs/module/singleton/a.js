define(function() {
  global.module_singleton_stack.push('init a')
});
