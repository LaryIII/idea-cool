define('c', null, function(require, exports) {

  exports.d = require('./d')
  exports.e = require('./e')
  exports.a = require('./a')
  exports.b = require('./b')

  exports.name = 'c'

})

define('f', [], { name: 'f' })
